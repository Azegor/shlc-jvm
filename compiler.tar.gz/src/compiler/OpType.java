package compiler;

public enum OpType {
	simple, compare, complex;
}