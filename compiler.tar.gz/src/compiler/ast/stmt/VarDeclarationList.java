package compiler.ast.stmt;


public abstract class VarDeclarationList extends LineNrStatement {
	public VarDeclarationList(int nr) {
		super(nr);
	}
}
