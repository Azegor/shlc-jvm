package compiler.ji;

public enum JasminType {
	int_t, long_t, short_t, float_t, double_t, byte_t, char_t, boolean_t;
}
