package compiler;

import grammar.shlBaseVisitor;

import compiler.ast.ASTNode;

public class ShlVisitor extends shlBaseVisitor<ASTNode> {

}
