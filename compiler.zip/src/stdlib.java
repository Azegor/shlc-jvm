public class stdlib {
	public static void prt(char c) {
		System.out.print(c);
	}

	public static void pln(char c) {
		System.out.println(c);
	}

	public static void prt(long l) {
		System.out.print(l);
	}

	public static void pln(long l) {
		System.out.println(l);
	}

	public static void prt(double d) {
		System.out.print(d);
	}

	public static void pln(double d) {
		System.out.println(d);
	}

	public static void prt(boolean b) {
		System.out.print(b);
	}

	public static void pln(boolean b) {
		System.out.println(b);
	}

	public static void prt(String s) {
		System.out.print(s);
	}
	public static void pln(String s) {
		System.out.println(s);
	}
}
